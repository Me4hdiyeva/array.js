let arr = [];
function add(){

let inp = document.getElementById('inp');
let btn = document.getElementById('btn');
let list = document.getElementById('list');

arr.push(inp.value);

let data = "";

for(let item of arr){
    data +=`<li class="list-group-item d-flex justify-content-between">${item} <button id="x" onclick="x" class="btn btn-danger btn-sm">x</button> </li>`
    if(inp.value== ''){
        
    } else{
answer = 'mumkun deyil'

}
}
list.innerHTML = data;

}


function x(){
    const x = [inp.value];
document.getElementById(inp).innerHTML = x;

x.splice(x, 0, 0);
document.getElementById(list).innerHTML = x;

}

